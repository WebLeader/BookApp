
module.exports = {
    AliStreaming: require('./AliStreaming').AliStreaming,
    AliPlayer: require('./AliPlayer').AliPlayer
}