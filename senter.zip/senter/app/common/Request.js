


export const LOGIN_ACTION = "LoginAction";  //用户登录

export const REGISTER_ACTION = "RegisterAction"; //用户注册