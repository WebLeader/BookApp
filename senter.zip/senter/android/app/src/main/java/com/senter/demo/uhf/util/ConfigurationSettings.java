package com.senter.demo.uhf.util;


public class ConfigurationSettings
{
	public static final String				key_Q			= "key_Q";

}
